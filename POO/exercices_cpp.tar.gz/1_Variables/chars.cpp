#include <iostream>
#include <typeinfo>
using namespace std;

int main(void) {
	for (int i = 0; i < 256; i++) {
		cout << char(i) << endl;
	}
}